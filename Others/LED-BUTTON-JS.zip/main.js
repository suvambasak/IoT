var Gpio = require("onoff").Gpio;

var led = new Gpio(4, "out");
var button = new Gpio(22, "in");

var ledStatus = false;
led.writeSync(0);

console.log("Ready...");

while (true) {
    if (button.readSync() === 1) {
        if (ledStatus) {
            console.log("BUTTON : CLICKED");
            console.log("LED : OFF");
            led.writeSync(0);
            ledStatus = false;
        }else {
            console.log("BUTTON : CLICKED");
            console.log("LED : ON");
            led.writeSync(1);
            ledStatus = true;
        }
    }
}