console.log('Hello from NodeJS');

//include onoff to interact with the GPIO
var Gpio = require('onoff').Gpio;

//use GPIO pin 4,24,23 and specify that it is output
var ledRed = new Gpio(4, 'out');
var ledYellow = new Gpio(23, 'out');
var ledGreen = new Gpio(24, 'out');
var blinkStatus = false;
ledRed.writeSync(0);
ledYellow.writeSync(0);
ledGreen.writeSync(0);


blinkLed();


function blinkLed() {
    while (true) {
        if (blinkStatus) {
            ledRed.writeSync(1);
            ledYellow.writeSync(1);
            ledGreen.writeSync(1);

            console.log('RED: ON');
            console.log('GREEN: ON');
            console.log('YELLOW: ON');

            blinkStatus = false;
            sleep(500);
        } else {
            ledRed.writeSync(0);
            ledYellow.writeSync(0);
            ledGreen.writeSync(0);

            console.log('RED: OFF');
            console.log('GREEN: OFF');
            console.log('YELLOW: OFF');
            
            blinkStatus = true;
            sleep(500);
        }
    }
}