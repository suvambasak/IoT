console.log('Hello from NodeJS');

//include onoff to interact with the GPIO
var Gpio = require('onoff').Gpio;

//use GPIO pin 4, and specify that it is output
var led = new Gpio(4, 'out');
led.writeSync(0);
var blinkStatus = false;

blinkLed();


function blinkLed() {
    while (true) {
        if (blinkStatus) {
            console.log('LED: ON');
            led.writeSync(1);
            blinkStatus = false;
            sleep(500);
        } else {
            console.log('LED: OFF');
            led.writeSync(0);
            blinkStatus = true;
            sleep(500);
        }
    }
}